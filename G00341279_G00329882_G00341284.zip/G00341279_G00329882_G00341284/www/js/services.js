var app = angular.module('myNews');

//dataGetService makes a single http request to the nasa api website.
//It returns a promise to the controller to let it know to wait for a
//response from the website before it continues.
//If the response is good, it resolves the promise and makes the data
//available.
//If the response is bad it rejects the promise with an error. 
app.service('dataGetService',function($http,$q){
	this.getData = function(){
		//Create a promise to send back to the controller
		var defer = $q.defer();

		//Create a new date which can be used to request data
		var date = new Date();
		var year = date.getFullYear();
		var month = date.getMonth()+1;
		var day = date.getDate();

		//Send a http request and wait for a response
		$http.get('https://api.nasa.gov/planetary/apod' + 
			'?api_key=MI5ggDDDWa8dsKQVOcFxBQjAUf5UGy5A9WeG6MjB' + '#' +
			year + "-" + month + "-" + day)
		.then(OK, NotOK);

		//If response is good, resolve the promise and return the data requested
		function OK(response){
			//Resolve the promise returned to the controller
			//Sends back the requested data
			defer.resolve(response.data);
		}

		//If response is bad, reject the promise and notify the user.
		function NotOK(response){
			alert("error " + response.status + " " + response.statusText);

			//Reject the promise returned to the controller. 
			defer.reject(response);
		}

	//Return a promise to the controller.
	//This will let the controller know to wait for the http response
	return defer.promise;
	}
});