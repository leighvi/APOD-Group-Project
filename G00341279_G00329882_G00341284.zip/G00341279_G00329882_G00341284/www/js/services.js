var app = angular.module('myNews');

/*
dataGetService makes a single http request to the nasa api website.
It calls back to a controller function on good or bad response to either
return the requested data or to return an error.
If the response is good, it calls the cbok function from the controller
and makes the data available.
If the response is bad it calls the cbnotok and returns the error data. 
*/
app.service('dataGetService',function($http,$sce){
	//Get todays date to hold as a persistant variable
	var date = new Date();
	//Set up last requested date to hold as a persistant variable
	//This is used to create the http request
	var lastDate;
	//Get one day in milliseconds
	//This is used to minus days from the last date requested
	var oneDay = 1000*60*60*24;
	//number of requests to me made
	var numRequests = 0;
	//number of completed requests
	var okRequests = 0;
	//temporary returned data array
	var requestedData = [];
	
	this.getData = function(cbok, cbnotok, dateMod, requests){

		//Check if you want todays image
		if(dateMod===0){
			lastDate = new Date();
			okRequests = 0;
			numRequests = requests;
			//empty temp array
			requestedData = [];
		}
		//otherwise get yesterdays date
		else{
			lastDate = new Date(lastDate.getTime()-oneDay);
		}
		
		//Check to see if current date for request is a sunday
		//If it is go back another day
		//There is no APOD on a sunday
		var newDateStr = lastDate.getDay();

		if(newDateStr === 0){
			lastDate = new Date(lastDate.getTime()-oneDay);
		}

		//create request url
		var APODrequest = 'https://api.nasa.gov/planetary/apod' + 
			'?api_key=MI5ggDDDWa8dsKQVOcFxBQjAUf5UGy5A9WeG6MjB' + '&date=' +
			lastDate.getFullYear() + "-" + (lastDate.getMonth()+1) + "-" + lastDate.getDate();

		//Send a http request and wait for a response
		$http.get(APODrequest)
		.then(OK, NotOK);

		//If response is good, resolve the promise and return the data requested
		function OK(response){
			okRequests++;
			//Convert data url into a trusted url for the iframe tag in html
			if(response.data.media_type === "video"){
				response.data.url = $sce.trustAsResourceUrl(response.data.url);
			}
			//push newest requested data into the temporary data array
			requestedData.push(response.data);
			//check if the last requested data has returned
			if(okRequests === numRequests){
				//sort requested data array before sending back to controller
				requestedData.sort(function(a,b){
					return new Date(b.date) - new Date(a.date);
				});
				//Return the data to the controller with a callback
				cbok(requestedData);
			}

		}

		//If response is bad, return the error data to the controller.
		function NotOK(response){
			//Return the error to the controller with a callback.
			cbnotok(response.data);
		}
	}
});

/*
contain the data and methods to set and recieve the number of requests to 
be made to the server as chosen by the user
*/
app.service('choiceService',function($http){
	var choice = 1;

	this.setChoice = function(val){
		choice = val;
	}

	this.getChoice = function(){
		return choice;
	}
});