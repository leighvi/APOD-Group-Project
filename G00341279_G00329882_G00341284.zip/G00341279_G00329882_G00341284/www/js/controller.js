var app = angular.module('myNews');

/*
Controller for the Main page which will display the requested data.
It calls the service dataGetService which has a function getData.
The getData function calls back to either the response ok(cbOK) or the
response not ok cbNOTOK and sends the value of the loop.
Once the request is resolved, data from the http request is available
and the data is then added to an array used to fill out the content of the main page
If the request is rejected (ie no response or bad reponse) a catch is triggered
which alerts the user.
*/
app.controller("MainCtrl", function($scope, dataGetService, choiceService){
	
	$scope.$on("$ionicView.beforeEnter",function(){
		$scope.returnedData = [];
		for(var i=0; i<choiceService.getChoice(); i++){
			dataGetService.getData(cbOK,cbNOTOK,i);
		}
	})
	
	
	//called from the dataGetService to return the requested data to the data array
	function cbOK(responseData,loops){
		$scope.returnedData.push(responseData);

		if(loops+1==choiceService.getChoice()){
			$scope.returnedData.sort(function(a,b){
				return a.date - b.date;
			});
		}
	}

	//called from the dataGetService on a bad response to notify the user
	function cbNOTOK(responseData) {
		alert(responseData);
	}

});

//Controller for the Settings page
app.controller('SettingsCtrl',function($scope, $state, choiceService){

	/*$scope.$on("$ionicView.beforeEnter",function(){
		$scope.choice = choiceService.getChoice();
	});*/

	$scope.setChoice = function(choice){
		choiceService.setChoice(choice);
		setTimeout(function () {
			$state.go("main");
		}, 500);
	}
});