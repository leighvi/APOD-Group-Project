var app = angular.module('myNews');
//var app = angular.module('myNews.controllers',[];)

//Controller for the Main page which will display the requested data.
//It calls the service dataGetService which has a function getData.
//The getData function returns a promise.
//Once the promise is resolved, data from the http request is available
//and the data is then used to fill out the content of the main page
//If the promise is rejected (ie no response or bad reponse) a catch is triggered
//which alerts the user.
app.controller("MainCtrl", function($scope, dataGetService){

	dataGetService.getData().then(function(data){

		//Create the content for the page from the returned data
		var newContent = "<ion-list>";
		newContent += "<ion-item>";
		newContent += "<p>" + data.title + "</p>";
		newContent += "<p>" + data.date + "</p>";
		newContent += "<p>" + data.explanation + "</p>";
		newContent += "<p><img src='" + data.url + "''></img></p>";

		//Add the content to the main page
		$('#main_Body').html(newContent);
		
	}).catch(function(){
		alert("Oh no, http response problem");
	});
});

//Controller for the Settings page
app.controller('SettingsCtrl',function($scope){
	
});