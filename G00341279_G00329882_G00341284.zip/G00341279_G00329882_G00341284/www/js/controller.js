var app = angular.module('myNews');

/*
Controller for the Main page which will display the requested data.
It calls the service dataGetService which has a function getData.
The getData function calls back to either the response ok(cbOK) or the
response not ok cbNOTOK and sends the value of the loop.
Once the request is resolved, data from the http request is available
and the data is then added to an array used to fill out the content of the main page
If the request is rejected (ie no response or bad reponse) a catch is triggered
which alerts the user.
*/
app.controller("MainCtrl", function($scope, dataGetService, choiceService){
	$scope.returnedData = [];
	
	$scope.$on("$ionicView.beforeEnter",function(){
		for(var i=0; i<choiceService.getChoice(); i++){
			dataGetService.getData(cbOK,cbNOTOK,i,choiceService.getChoice());
		}
	})
	
	
	//called from the dataGetService to return the requested data to the data array
	function cbOK(responseData){
		$scope.returnedData = responseData;
	}

	//called from the dataGetService on a bad response to notify the user
	function cbNOTOK(responseData) {
		alert(responseData.error);
	}

});

/*
Controller for the Settings page
Sets the current radio button checked
On radio button click update the number of requests in the choiceService then
wait half a second before returning to the main page automatically
*/
app.controller('SettingsCtrl',function($scope, $state, choiceService){
	$scope.choice = choiceService.getChoice();

	$scope.setChoice = function(choice){
		choiceService.setChoice(choice);
		setTimeout(function () {
			$state.go("main");
		}, 500);
	}
});